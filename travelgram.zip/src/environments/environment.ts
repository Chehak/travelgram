// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: true,
   firebase : {
    apiKey: "AIzaSyCFi1JNVpLiax1RA1ObFWoFxn6AOOp-nmU",
    authDomain: "my-project-1565249186921.firebaseapp.com",
    projectId: "my-project-1565249186921",
    storageBucket: "my-project-1565249186921.appspot.com",
    messagingSenderId: "175610999899",
    appId: "1:175610999899:web:70f16b8e1efc809bbd3b7e"
  },
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
